#include "lib.h"
#include "../fmtlog.h"

void libFun(int i) {
  logi("libFun: {}", i);
}

