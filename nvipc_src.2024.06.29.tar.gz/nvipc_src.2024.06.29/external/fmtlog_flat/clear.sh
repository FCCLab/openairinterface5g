rm fmtlog.txt spdlog.txt nanalog.bin compressedLog 
